FS25 static baked fillPlanes v3
================================

Исправлено освещение.

Причина:
игровые $data/fillPlanes/*_normal.dds предназначены для штатного
fillPlane shader / texture arrays. При прямом использовании в обычном
Material они дают неверную реакцию на свет.

Что сделано:
- геометрические normals НЕ инвертировались: они уже были правильными;
- diffuse оставлен из версии v2;
- gloss оставлен из версии v2;
- normal maps заново сгенерированы из штатных *_height.dds как обычные
  tangent-space RGB normal maps;
- fillPlaneShader не используется;
- модели остаются полностью статическими, без Lua.

Файлы normal:
textures/hay_static_normal.dds
textures/silage_static_normal.dds
textures/straw_static_normal.dds
